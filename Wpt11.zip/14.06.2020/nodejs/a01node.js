function f1(x)
{
	console.log("f1 function called");
	return x*3;
}

console.log(f1(4));